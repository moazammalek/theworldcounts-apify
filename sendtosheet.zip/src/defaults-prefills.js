// prefill transform function

// this code works the same as if you delete it and leave this area blank
({ spreadsheetData, datasetData }) => {
    return spreadsheetData.concat(datasetData);
}
