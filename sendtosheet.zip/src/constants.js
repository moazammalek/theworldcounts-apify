module.exports = {
    CLIENT_ID: '118138324390-1nmbvv5q2nffuagp65i03k086qr173jg.apps.googleusercontent.com',
    REDIRECT_URI: 'urn:ietf:wg:oauth:2.0:oob',
    // REDIRECT_URI: 'https://apify.com',
    CLIENT_ID_2: '211810992764-n3k9d189h8h631vnvviock7ui5mu1ak1.apps.googleusercontent.com',
};
