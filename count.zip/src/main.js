/**
 * This template is a production ready boilerplate for developing with `PlaywrightCrawler`.
 * Use this to bootstrap your projects using the most up-to-date code.
 * If you're looking for examples or want to learn more, see README.
 */
console.time("logtime");
// For more information, see https://sdk.apify.com
import { Actor } from "apify";
// For more information, see https://crawlee.dev
import { Dataset, KeyValueStore, PlaywrightCrawler } from "crawlee";
import { router } from "./routes.js";

// Initialize the Apify SDK
await Actor.init();

const startUrls = [
    {
        url: "https://www.worldometers.info/",
        label: "worldometers",
    },
    {
        url: "https://www.theworldcounts.com/challenges/toxic-exposures/use-of-chemicals",
        label: "chemicals",
    },
    {
        url: "https://www.theworldcounts.com/challenges/climate-change/global-warming",
        label: "global_warming",
    },
    {
        url: "https://www.theworldcounts.com/challenges/climate-change/energy",
        label: "energy",
    },
    {
        url: "https://www.theworldcounts.com/challenges/planet-earth/waste",
        label: "waste",
    },
    {
        url: "https://www.theworldcounts.com/challenges/planet-earth/forests-and-deserts",
        label: "forests",
    },
    {
        url: "https://www.theworldcounts.com/challenges/planet-earth/oceans",
        label: "oceans",
    },
    {
        url: "https://www.theworldcounts.com/challenges/planet-earth/air",
        label: "air",
    },
    {
        url: "https://www.theworldcounts.com/challenges/planet-earth/mining",
        label: "mining",
    },
    {
        url: "https://www.theworldcounts.com/challenges/planet-earth/freshwater",
        label: "freshwater",
    },
    {
        url: "https://www.theworldcounts.com/challenges/planet-earth/state-of-the-planet",
        label: "planet",
    },
    { url: "https://www.theworldcounts.com/challenges", label: "challenges" },
    {
        url: "https://www.theworldcounts.com/challenges/consumption/foods-and-beverages",
        label: "foods",
    },
    {
        url: "https://www.theworldcounts.com/challenges/consumption/clothing",
        label: "clothing",
    },
    {
        url: "https://www.theworldcounts.com/challenges/consumption/other-products",
        label: "other",
    },
    {
        url: "https://www.theworldcounts.com/challenges/people-and-poverty",
        label: "people",
    },
];

// const proxyConfiguration = await Actor.createProxyConfiguration();

const crawler = new PlaywrightCrawler({
    // proxyConfiguration,
    requestHandler: router,
    minConcurrency: 2,
    // maxConcurrency: 10,
});

await crawler.run(startUrls);
let x = await Promise.all(
    startUrls.map((s) => {
        return KeyValueStore.getValue(s.label);
    })
);
const time = new Date();
let data = { time };
x.forEach((y) => {
    data = { ...data, ...y };
});
await Dataset.pushData(data);
await Actor.call('glaring_santoor/login',{
    "createBackup": false,
    "deduplicateByEquality": false,
    "keepSheetColumnOrder": true,
    "columnsOrder": [
        "time",
        "tons_of_pesticides_used",
        "tons_of_hazardous_waste_produced",
        "tons_of_bisphenol_a_produced",
        "tons_of_pvc_plastics_produced",
        "tons_of_phthalates_produced",
        "tons_of_co2_emitted_into_the_atmosphere",
        "world_average_temperature",
        "rise_in_sea_levels",
        "tons_of_melted_ice",
        "terajoules_of_energy_used",
        "percent_of_electricity_produced_from_renewable_sources",
        "terajoules_of_solar_energy_striking_earth",
        "terajoules_of_electricity_used",
        "time_left_to_the_end_of_oil",
        "tons_of_waste_from_households",
        "tons_of_electronic_waste_thrown_out",
        "number_of_plastic_bags_produced",
        "great_pacific_garbage_patch",
        "tons_of_hazardous_waste_thrown_out",
        "tons_of_waste_dumped",
        "hectares_of_forests_cut_down_or_burned",
        "percent_of_wild_forests_left",
        "cubic_metres_of_roundwood_from_responsibly_managed_forests",
        "hectares_of_replanted_forests",
        "square_kilometers_of_land_area_being_degraded",
        "cubic_meters_of_wood_produced",
        "percent_of_species_in_critical_risk_of_extinction",
        "tons_of_seafood_produced",
        "percent_coral_reefs_left",
        "time_left_to_the_end_of_seafood",
        "tons_of_discarded_fish",
        "tons_of_plastic_waste_dumped_in_oceans",
        "years_of_healthy_life_lost_from_air_pollution",
        "deaths_from_air_pollution",
        "time_left_to_recovery_of_the_ozone_hole",
        "deaths_from_indoor_air_pollution",
        "liters_of_air_that_you_have_inhale",
        "tons_of_resources_mined_from_earth",
        "tons_of_gold_mined",
        "tons_of_toxic_waste_produced_from_gold_mining",
        "tons_of_coal_mined",
        "tons_of_steel_recycled",
        "tons_of_steel_produced",
        "tons_of_wastewater_from_steel_mining",
        "energy_use_from_mining",
        "tons_of_freshwater_used",
        "tons_of_virtual_water_traded",
        "liters_of_water_you_have_used",
        "deaths_from_dirty_water_and_related_diseases",
        "number_of_people_in_need_of_water",
        "tons_of_groundwater_being_polluted",
        "tons_of_water_used_for_our_consumption",
        "world_population",
        "tons_of_resources_extracted_from_earth",
        "tons_of_waste_dumped",
        "earth_running_out_of_food",
        "tons_of_solid_waste_generated",
        "time_left_till_no_more_fish_in_the_sea",
        "time_left_till_the_end_of_rainforests",
        "cars_produced",
        "tons_of_food_lost_or_wasted",
        "tons_of_meat_eaten",
        "tons_of_water_used_in_meat_production",
        "tons_of_antibiotics_used_for_livestock",
        "aluminium_cans_consumed",
        "recycled_aluminium_cans",
        "us_dollars_spent_on_organic_food",
        "tons_of_cotton_produced",
        "tons_of_organic_cotton_produced",
        "us_dollars_spent_on_cotton_pesticides",
        "tons_of_water_used_in_cotton_production",
        "tons_of_paper_produced",
        "gigajoules_used_in_households",
        "number_of_obese_people",
        "people_who_died_from_hunger",
        "tox_chem_this_year",
        "soil_erosion_this_year",
        "desert_land_formed_this_year",
        "oil_reserves",
        "energy_used_today",
        "energy_nonren",
        "oil_consumption",
        "oil_days",
        "gas_reserves",
        "gas_days",
        "coal_reserves",
        "coal_days"
    ],
    "mode": "append",
    "publicSpreadsheet": false,
    "range": "result",
    "rawData": [data],
    "spreadsheetId": "1N3LpoB77GiHiuQtl_8olNs0TOGtEGCWoUSangCGtTRw",
    "transformFunction": "// Uncomment this code only if you don't use \"Deduplicate by field\" or \"Deduplicate by equality\"\n// This code behaves as if there was no transform function\n/*({ spreadsheetData, datasetData }) => {\n    return spreadsheetData.concat(datasetData);\n}*/"
})

// Exit successfully
await Actor.exit();
console.timeEnd("logtime");
