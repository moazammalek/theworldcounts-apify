import { KeyValueStore, Dataset, createPlaywrightRouter } from "crawlee";
import { selector } from "./selector.js";
export const router = createPlaywrightRouter();

router.addDefaultHandler(async ({ request, page, log }) => {
    const title = await page.title();
    log.info(`${title}`, { url: request.loadedUrl });

    const data = await page.evaluate((selectors) => {
        document.querySelectorAll(".counter-main")?.forEach(($this) => {
            $this.setAttribute("data-content", $this.innerHTML.toLowerCase());
        });
        let data = {};
        Object.keys(selectors).forEach((key) => {
            data[key] = 
                document
                    .querySelector(selectors[key])
                    ?.innerText?.replaceAll(",", "")
            data[key].includes(".")?parseFloat(data[key]):parseInt(data[key])
        });
        return data;
    }, selector[request.label]);

    // const storeData = await KeyValueStore.getValue("data");
    // storeData
    //     ? await KeyValueStore.setValue("data", { ...data, ...storeData })
    //     : await KeyValueStore.setValue("data", { ...data });
    await KeyValueStore.setValue(request.label, { ...data });
    // await Dataset.pushData(data);
});
